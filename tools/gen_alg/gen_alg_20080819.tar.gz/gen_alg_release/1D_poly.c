/*--------------------------------------------------------------------------------------------------
/
/ Filename: 1D_poly.c
/ Author: Jay Billings
/ Description: This program maximizes the 1D polynomial (-x^4+99x^3-4x^2+35x-775)/(43x^2-105x+70).
/              A function is created to evaluate the polynomial above "the old fashioned way" and
/              it is then duplicated to run in the genetic algorithm, functions y(n,x) and z(n,x)
/              respectively.
/ Date: 2007/07/12
*///------------------------------------------------------------------------------------------------

#include <stdio.h> /* Includes standard IO functions */
#include <math.h> /* Includes math functions */
#include "gen_alg.h" /* Includes the genetic algorithm header file */


float func1(int, float[]);
float func2(int, float[]);

main (int argc, char **argv) {
     int n = 1;
     int i;
     float x[n], ctrl[12];
     float value, z_value;

     printf("Testing to make sure the function works... \n");
     for(i = 0; i < 10; ++i) {
        x[0] = 10.0*i;
        value = func1(n,x);
        printf("For x = %f, y(n,x) = %f \n", x[0], value);
     }

//     printf("Creating output of 0 <= y <= 100 for ", \
                 "graphical check in fort.20...");
/*     for (i = 0; i < 100; ++i) {
        x[0] = i;
        value = y(n,x);
        fputf;
     }
*/
     printf("Attempting to maximize the function... \n");
     for (i = 0; i < 12; ++i) {
         ctrl[i] = -1.0;
     }
     ctrl[0] = 100.0;
     ctrl[1] = 100.0;
     ctrl[2] = 0.0;
     ctrl[3] = 0.5;
     ctrl[4] = 0.03;
     gen_alg(n,x,ctrl,func2);

     printf("\n End program 1D_poly. \n");
     return;
}

float func1(int n, float x[]) {
     float x_local, y;

     x_local = x[0]; //Defined as such in case x needs to be scaled.
     printf("x_local %f \n",x_local);
     y = (-pow(x_local,4.0)+99.0*pow(x_local,3.0)-4.0*pow(x_local,2.0)+35.0*x_local-775.0)/ \
         (43.0*pow(x_local,2.0)-105.0*x_local+70.0);
     
     return y;
}

float func2(int n, float x[]) {
     float x_local, z;

     x_local = 100.0*x[0]; //Defined as such in case x needs to be scaled.
     z = (-pow(x_local,4.0)+99.0*pow(x_local,3.0)-4.0*pow(x_local,2.0)+35.0*x_local-775.0)/ \
         (43.0*pow(x_local,2.0)-105.0*x_local+70.0);
     //printf("Am I dying here?\n");    
 
     return z;
}
