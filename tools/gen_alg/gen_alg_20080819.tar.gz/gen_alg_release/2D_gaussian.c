/*--------------------------------------------------------------------------------------------------
/
/ Filename: 2D_gaussian.c
/ Author: Jay Billings
/ Description: This program maximizes the 2D Gaussian z = e^(-x^2-y^2) in both the "old-fashioned
/	       way and using the genetic algorithm.
/ Date: 2007/07/12
*///------------------------------------------------------------------------------------------------

#include <stdio.h> /* Includes standard IO functions */
#include <math.h> /* Includes math functions */
#include "gen_alg.h" /* Includes the genetic algorithm header file */


float func1(int, float[]);
float func2(int, float[]);

main (int argc, char **argv) {
     int n = 2;
     int i;
     float x[n], ctrl[5];
     float value, z_value;

     printf("Testing to make sure the function works... \n");
     for(i = 0; i < 10; ++i) {
        x[0] = 0.1*i;
        x[1] = 0.1*i;
        value = func1(n,x);
        printf("For x = %f, y = %f, z(n,x) = %f \n", x[0], x[1], value);
     }

//     printf("Creating output of 0 <= y <= 100 for ", \
                 "graphical check in fort.20...");
/*     for (i = 0; i < 100; ++i) {
        x[0] = i;
        value = y(n,x);
        fputf;
     }
*/
     printf("Attempting to maximize the function... \n");
     for (i = 0; i < 5; ++i) {
         ctrl[i] = -1.0;
     }
     ctrl[0] = 100.0;
     ctrl[1] = 100.0;
     ctrl[2] = 0.0;
     ctrl[3] = 0.5;
     ctrl[4] = 0.03;
     gen_alg(n,x,ctrl,func2);

     printf("\n End program 2D_gaussian. \n");
     return 0;
}

float func1(int n, float x[]) {
     float x_local, y_local, out;

     x_local=x[0];
     y_local=x[1];
     printf("x_local = %f, y_local = %f \n",x_local,y_local);
     out = exp(-(pow(x_local,2.0)+pow(y_local,2.0)));
     
     return out;
}

float func2(int n, float x[]) {
     float x_local, y_local, z;
     int m;

     x_local=10.0*x[0];
     y_local=10.0*x[1];
     z = exp(-(pow(x_local,2.0)+pow(y_local,2.0)));
     
     //printf("Am I dying here?\n");    
 
     return z;
}
