/*-----------------------------------------------------------------------------
/
/ Filename: gen_alg.c
/ Author: Jay Billings
/ Author's email: jayjaybillings@gmail.com
/ Description: This code is a genetic algorithm and can be used to maximize or
/              minimize functions. The code is largely based on Pikaia with 
/              some changes made to suit the author's tastes.
/
/	       To call the function,
/
/			gen_alg(n,x,ctrl,fit_func)
/
/              where 
/
/			n = an integer number of dimensions of the vector x
/                       x = an array of floats, size n
/                       ctrl = control variables
/				ctrl[0] = # population members
/				ctrl[1] = # generations
/				ctrl[2] = crossover type, 0 = single-point
/				          1 = two-point,
/				          2 = multi-point
/				ctrl[3] = birth rate
/				ctrl[4] = mutation rate
/
/ Copyright Information:
/
/ Copyright (c) 2008       Jay Jay Billings
/
/ This program is free software; you can redistribute it and/or modify
/ it under the terms of the GNU General Public License as published by
/ the Free Software Foundation; either version 2 of the License, or
/ (at your option) any later version.
/
/ This program is distributed in the hope that it will be useful,
/ but WITHOUT ANY WARRANTY; without even the implied warranty of
/ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
/ GNU General Public License for more details.
/
/ You should have received a copy of the GNU General Public License
/ along with this program; if not, write to the Free Software
/ Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
/
/ The license is also available at:
/
/		http://www.gnu.org/copyleft/gpl.html .
/
/ Date: 2007/06/06
/
*///---------------------------------------------------------------------------

//For ran0
#define    IA 16807
#define    IM 2147483647
#define    AM (1.0/IM)
#define    IQ 127773
#define    IR 2836
#define    MASK 123459876

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "gen_alg.h"

int max_rows = 500, //No populations larger than 500 members, at the moment.
    max_cols = 50; //Who needs more than 50 adjustable parameters? (I may eat this!)
long seed = 123456;
float max_fitness;

float gen_alg( int n, float x[], float ctrl[], float fit_func( int, float[])) {

   int a, b, i, j, k, l, parent1, parent2, return_value;
   int pop_size, gens, cross_type;
   int rank[max_rows];

   float value, cross_prob, mut_prob, c1_fitness, c2_fitness;
   float population[max_rows][max_cols], x_send[n], fitness[max_rows];
   float fitness_send[max_rows];
   float p1_chromo[max_rows], p2_chromo[max_rows], c1_chromo[max_rows];
   float c2_chromo[max_rows], c1_pheno[n], c2_pheno[n];

   FILE *fp;

   char buf[200];

//Testing/Debug stuff
   for (i = 0; i < n; ++i) {
       x[i] = 0.0;
   }
   value = fit_func(n,x);
   printf("Testing fitness function. Result: %f \n", value);

//Debug stuff
   value = ran0(&seed); 
   printf("Testing random number generator. Result: %f \n", value);

//Initializes the control variables
   for (i = 0; i < 5; ++i) {
       controller(i,&ctrl[i]);
   }
   pop_size = ctrl[0];
   gens = ctrl[1];
   cross_type = ctrl[2];
   cross_prob = ctrl[3];
   mut_prob = ctrl[4];

//Initialize matrices, arrays, and variables
   for (i = 0; i < max_rows; ++i) {
       for (j = 0; j < max_cols; ++j) {
           population[i][j] = 0.0;
       }
       x_send[i] = 0.0;
       fitness[i] = -10000000000.0;
       rank[i] = 0.0;
       p1_chromo[i] = 0.0;
       p2_chromo[i] = 0.0;
       c1_chromo[i] = 0.0;
       c2_chromo[i] = 0.0;
   }
   for (i = 0; i < n; ++i ) {
       c1_pheno[i] = 0.0;
       c2_pheno[i] = 0.0;
   }
   parent1 = 0;
   parent2 = 0;

//Sets the initial population with individual members as the rows of the matrix
   for (i = 0; i < pop_size; ++i) {
      // printf("%d: ",i);
       for (j = 0; j < n; ++j) {
     //      population[i][j] = rng();
           population[i][j] = ran0(&seed);
      // printf("%f ",population[i][j]);
       }
      // printf("\n");
   }

//Check the fitness of the initial members
   for (i = 0; i < pop_size; ++i) {
       fitness[i] = fit_func(n, population[i]);
       rank[i] = i;
   }
//Sort the fitness array and return the ranks
   quicksort2(fitness,rank,0,max_rows-1);

   for (i = 0; i < gens; ++i) {
       sprintf(buf,"c.%d",i+1);
       // printf("-----GENERATION %d -----\n",i);
       for (j = max_rows-pop_size; j < max_rows; j=j+2) {
//           printf("----- \n");
           get_parents(pop_size,fitness,rank,&parent1,&parent2);
        //   printf("Parent1 = %d, Parent2 = %d, Calling encode_parents... \n", parent1,parent2);
           encode_chromo(n,population[parent1],population[parent2],p1_chromo,p2_chromo);
           if (ran0(&seed) < cross_prob) {
              if (cross_type == 0) {
                 one_point_cross(n,p1_chromo,p2_chromo,c1_chromo,c2_chromo);
              } else if (cross_type == 1) {
                 two_point_cross(n,p1_chromo,p2_chromo,c1_chromo,c2_chromo);
              } else {
                 multi_point_cross(n,p1_chromo,p2_chromo,c1_chromo,c2_chromo);
              }  
              decode_chromo(n,c1_chromo,c2_chromo,c1_pheno,c2_pheno);
              //Check for child 1 mutation
              mutate(mut_prob, c1_pheno);
              //Check for child 2 mutation
              mutate(mut_prob, c2_pheno);
              c1_fitness = fit_func(n, c1_pheno);
	      c2_fitness = fit_func(n, c2_pheno);
              for (k = max_rows-pop_size; k < max_rows-1; ++k) {
                    if (c1_fitness >= fitness[k]) {
                       fitness[k] = c1_fitness;
                       for (l = 0; l < n; ++l) {
                           population[rank[k]][l] = c1_pheno[l];
                       }
                       break;
                    }
              }
              for (k = max_rows-pop_size; k < max_rows-1; ++k) {
		   if (c2_fitness >= fitness[k]) {
                        fitness[k] = c2_fitness;
                        for (l = 0; l < n; ++l) {
                            population[rank[k]][l] = c2_pheno[l];
                        }
                        break;
                   }
              }
           }
       }
       //fclose(fp);
      // printf("Maximum fitness this generation: %f \n", fitness[max_rows-1]);
   }

//This block is used for diagnostic/testing purposes. Maybe later it can be used for output.
//   printf("\nParent1: %d , Parent2: %d \n",parent1,parent2);
/*   for (i = 0; i < max_rows; ++i) {
       printf("*---Chromosomes---* \n %d Parent 1: %f Parent 2: %f \n", i, p1_chromo[i], p2_chromo[i]);
   }*/
  // printf("\n");
   //for (i = 0; i < n; ++i) {
     //  printf("*---Phenotypes---* \n %d Parent 1: %f Parent 2: %f \n", i, c1_pheno[i], c2_pheno[i]);
  // }
   
/*   for (i = 0; i < pop_size; ++i) {
       printf("%d: ",i);
       for (j = 0; j < n; ++j) {
       printf("%f ",population[i][j]);
       }
       printf("\n");
   }
   for (i = max_rows-pop_size; i < max_rows; ++i) {
       printf("fitness[%d] = %f rank[%d] = %d \n", i, fitness[i], i, rank[i]);
   }
  // printf("fitness = %f \n", fitness[max_rows-pop_size-1]);
 */

//Output most evolved pair to screen
   for (i = 0; i < n; ++i) {
       printf("x[%d] = %f , ",i,population[rank[max_rows-pop_size]][i]);
   }
   printf("fitness = %f \n", fitness[max_rows-pop_size]);

   return fitness[max_rows-pop_size];
}

/* ----- Functions needed for the genetic algorithm are coded below ----- */

float rng() {

   float number;

   number = (rand() % 100000)/100000.0;

   return number;
}

void controller(int marker, float *ctrlptr) {

       //Check for unrealistic values
       if (*ctrlptr < 0) {
          *ctrlptr = 0.0; 
       }
       //Population setting
       if (marker == 0 && *ctrlptr == 0.0) {
          printf("Setting population size to default value of 100.\n");
          *ctrlptr = 100.0;
       }
       //Generational setting
       if (marker == 1 && *ctrlptr == 0.0) {
          printf("Setting number of generations to default value of 10.\n");
          *ctrlptr = 10.0;
       }
       //Crossover type setting
       if (marker == 2 && *ctrlptr == 0.0) {
          printf("Using default 1-point crossover type.\n");
       }
       //Crossover probability setting
       if (marker == 3 && *ctrlptr == 0.0) {
          *ctrlptr = 0.5;
          printf("Using default crossover probability of 1/2.\n");
       }
       //Mutation probability setting
       if (marker == 4 && *ctrlptr == 0.0) {
          *ctrlptr = 0.03;
          printf("Using default mutation probability of 1/2.\n");
       }

       return;
}

void get_parents(int pop_size, float fitness[], int rank[], int *parent1ptr, int *parent2ptr) {

      int i;
      float prob, sum, summed_fitness, local_summed_fitness;

//Get summed fitness
      summed_fitness = 0.0;
      for (i = max_rows-pop_size; i < max_rows; ++i) {
          summed_fitness = summed_fitness + fitness[i];
      }

//Get parent 1
      prob = ran0(&seed);
      local_summed_fitness = 0.0;
      for (i = max_rows-pop_size; i < max_rows; ++i) {
          local_summed_fitness = local_summed_fitness + fitness[i];
          if ((local_summed_fitness/summed_fitness) > prob) {
             *parent1ptr = rank[i];
             break;
          }
      }

      prob = ran0(&seed);
      local_summed_fitness = 0.0;
      for (i = max_rows-pop_size; i < max_rows; ++i) {
          local_summed_fitness = local_summed_fitness + fitness[i];
          if ((local_summed_fitness/summed_fitness) > prob) {
             *parent2ptr = rank[i];
             break;
          }
      }

      if (*parent1ptr == *parent2ptr) {
         get_parents(pop_size,fitness,rank,parent1ptr,parent2ptr);
      }


      return;

}

void encode_chromo(int n, float p1_pheno[], float p2_pheno[], float p1_chromo[], float p2_chromo[]) {

      int i;
      
      for (i = 0; i < n; ++i) {
          p1_chromo[i*10] = p1_pheno[i];
          p2_chromo[i*10] = p2_pheno[i];
      }

      return;
}

void decode_chromo(int n, float c1_chromo[], float c2_chromo[], float c1_pheno[], float c2_pheno[]) {

      int i;

      for (i = 0; i < n; ++i) {
          c1_pheno[i] = c1_chromo[i*10];
          c2_pheno[i] = c2_chromo[i*10];
      }

      return;
}

void one_point_cross(int n, float p1_chromo[], float p2_chromo[], float c1_chromo[], float c2_chromo[]) {

      int i, splice;
//Picks the splice
      splice = ran0(&seed)*(n-1)*10;

//Performs the crossover
      for (i = 0; i < splice; ++i) {
          c1_chromo[i] = p1_chromo[i];
          c2_chromo[i] = p2_chromo[i];
      }
      for (i = splice; i < max_rows; ++i) {
          c1_chromo[i] = p2_chromo[i];
          c2_chromo[i] = p1_chromo[i];
      }

      return;
}

void two_point_cross(int n, float p1_chromo[], float p2_chromo[], float c1_chromo[], float c2_chromo[]) {

      int i, splices[2];

//Picks splice points and check their uniqueness
      splices[0] = ran0(&seed)*(n-1)*10;
      splices[1] = ran0(&seed)*(n-1)*10;
      if (splices[0] == splices[1]) {
         splices[1] = ran0(&seed)*(n-1)*10;
         if (splices[0] == splices[1]) {
            printf("Unable to create unique splice points in function 'two_point_cross.' \
                   How's your random number generator these days? \n");
         }
      }
      bsort_int(splices,2);

//Performs the two-point crossover
      for (i = 0; i < splices[0]; ++i) {
          c1_chromo[i] = p1_chromo[i];
          c2_chromo[i] = p2_chromo[i];
      }
      for (i = splices[0]; i < splices[1]; ++i) {
          c1_chromo[i] = p2_chromo[i];
          c2_chromo[i] = p1_chromo[i];
      }
      for (i = splices[1]; i < max_rows; ++i) {
          c1_chromo[i] = p1_chromo[i];
          c2_chromo[i] = p2_chromo[i];
      }
 
      return;
}

void multi_point_cross(int n, float p1_chromo[], float p2_chromo[], float c1_chromo[], float c2_chromo[]) {

      int i, splices[5];

//Pick splice points and check their uniqueness
      for (i = 0; i < 5; ++i) {
          splices[i] = ran0(&seed)*(n-1)*10;
      }
      for (i = 0; i < 5; ++i) {
          if (i > 0 && splices[i] == splices[i-1]) {
             splices[i] = ran0(&seed)*(n-1)*10;
             if (splices[i] == splices[i-1]) {
                printf("Unable to create unique splice points in function 'multi_point_cross.' \
                       How's your random number generator these days? \n");
             }
          }
      }
      bsort_int(splices,5);
    
//Performs the multi-point crossover
      for (i = 0; i < splices[0]; ++i) {
          c1_chromo[i] = p1_chromo[i];
          c2_chromo[i] = p2_chromo[i];
      }
      for (i = splices[0]; i < splices[1]; ++i) {
          c1_chromo[i] = p1_chromo[i];
          c2_chromo[i] = p2_chromo[i];
      }
      for (i = splices[1]; i < splices[2]; ++i) {
          c1_chromo[i] = p1_chromo[i];
          c2_chromo[i] = p2_chromo[i];
      }
      for (i = splices[2]; i < splices[3]; ++i) {
          c1_chromo[i] = p1_chromo[i];
          c2_chromo[i] = p2_chromo[i];
      }
      for (i = splices[3]; i < splices[4]; ++i) {
          c1_chromo[i] = p1_chromo[i];
          c2_chromo[i] = p2_chromo[i];
      }

      return;
}

void mutate(float mut_prob, float c_chromo[]) {

     int i;

//Child mutation  
     i = 0;
     while(i < max_cols) {
          if (ran0(&seed) < mut_prob) {
             c_chromo[i] = c_chromo[i] - 0.1*c_chromo[i];
          }
          ++i;
     }

     return;
}

void bsort_int(int a[], int size) {
     
     int i, j, pass, btmp;
     float atmp;

     for (i = 0; i <= size-1; ++i) {
         for (j = 0; j <= size-2; ++j) {
             if (a[j] > a[j+1]) {
                atmp = a[j];
                a[j] = a[j+1];
                a[j+1] = atmp;
             }
         }
     }

     return;
}

void bsort2(float a[], int b[]) {
     
     int i, j, pass, btmp;
     float atmp;

     for (i = 0; i <= max_rows-1; ++i) {
         for (j = 0; j <= max_rows - 2; ++j) {
             if (a[j] > a[j+1]) {
                atmp = a[j];
                a[j] = a[j+1];
                a[j+1] = atmp;
                btmp = b[j];
                b[j] = b[j+1];
                b[j+1] = btmp;
             }
         }
     }

     return;
}

/* FROM NUMERICAL RECIPES IN C, CHAPTER 7
“Minimal” random number generator of Park and Miller. Returns a uniform random deviate
between 0.0 and 1.0. Set or reset idum to any integer value (except the unlikely value MASK)
to initialize the sequence; idum must not be altered between calls for successive deviates in
a sequence.*/

float ran0(long *idum)
{
     long k;
     float ans;
     *idum ^= MASK;                         
     k=(*idum)/IQ;                          
     *idum=IA*(*idum-k*IQ)-IR*k;            
     if (*idum < 0) *idum += IM;            
     ans=AM*(*idum);                        
     *idum ^= MASK;                         
     return ans;
}
