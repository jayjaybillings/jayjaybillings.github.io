/*---------------------------------------------------------------------
/
/ Filename: quicksort.c
/ Function name: quickSort
/ Author: Jay Billings
/ Description: This code was written using pseudocode found at
/              Wikipedia in the Quicksort article. It is used to sort
/              arrays in the genetic algorithm code authored in the
/              Astrophysics group at the University of Tennessee. 
/              There are two implementations in this file: one for 
/              sorting a single integer array and another for sorting
/              two arrays, one float one integer.
/ Date Taken: 6/15/2007
*///-------------------------------------------------------------------

#include <stdio.h>

void quicksort(int a[], int l, int r) {

   int j, pivotIndex, pivotNewIndex;

   if( r > l ) {
       pivotIndex = l;
       pivotNewIndex = partition(a, l, r, pivotIndex);
       quicksort(a, l, pivotNewIndex-1);
       quicksort(a, pivotNewIndex+1, r);
   }
	
}

int partition(int a[], int l, int r, int pivotIndex) {

   int i, storedIndex, k, rtmp;
   float pivot, tmp;

   pivot = a[pivotIndex];

   //Swaps values faster than calling a function.
   tmp = a[pivotIndex];
   a[pivotIndex] = a[r];
   a[r] = tmp;
   
   storedIndex = l;
   for (i = l; i < r; ++i) {
       if (a[i] <= pivot) {
          tmp = a[storedIndex];
          a[storedIndex] = a[i];
          a[i] = tmp;
          storedIndex = storedIndex + 1;
       }   
   }
   if (a[r] <= a[storedIndex]) {
      tmp = a[storedIndex];
      a[storedIndex] = a[r];
      a[r] = tmp;
      return storedIndex;
   } else {
      return r;
   }

}

void quicksort2( float a[], int b[], int l, int r) {

   int j, pivotIndex, pivotNewIndex;

   if( r > l ) {
       pivotIndex = (l+r)/2;
       pivotNewIndex = partition2( a, b, l, r, pivotIndex);
       quicksort2( a, b, l, pivotNewIndex-1);
       quicksort2( a, b, pivotNewIndex+1, r);
   }
	
}

int partition2( float a[], int b[], int l, int r, int pivotIndex) {

   int i, storedIndex, k, rtmp;
   float pivot, tmp;

   pivot = a[pivotIndex];

   //Swaps values faster than calling a function.
   tmp = a[pivotIndex];
   a[pivotIndex] = a[r];
   a[r] = tmp;
   
   rtmp = b[pivotIndex];
   b[pivotIndex] = b[r];
   b[r] = rtmp;

   storedIndex = l;
   for (i = l; i < r; ++i) {
       if (a[i] <= pivot) {
          tmp = a[storedIndex];
          a[storedIndex] = a[i];
          a[i] = tmp;

          rtmp = b[storedIndex];
          b[storedIndex] = b[i];
          b[i] = rtmp;

          storedIndex = storedIndex + 1;
       }   
   }
   if (a[r] <= a[storedIndex]) {
      tmp = a[storedIndex];
      a[storedIndex] = a[r];
      a[r] = tmp;
   
      rtmp = b[storedIndex];
      b[storedIndex] = b[r];
      b[r] = rtmp;

      return storedIndex;
   } else {
      return r;
   }

}

void quicksort3( float a[], int b[], int rows) {

   int i, j, k, storedIndex, rtmp, l, r, bpivot;
   int begin[1000], end[1000];
   float pivot, tmp;
  
   i = 0;
   begin[0] = 0;
   end[0] = rows;
   while (i >= 0) {
         l = begin[i];
         r = end[i]-1;
         if (l < r) {
            pivot = a[l];
            bpivot = b[l];
            if (i == 1000-1) return;
	    while (l < r) {
                  while (a[r] >= pivot && l < r) --r;
                  if (l < r) {
                     a[++l] = a[r];
                     b[++l] = b[r];
                  }
                  while (a[l] >= pivot && l < r) ++l;
                  if (l < r) {
                     a[--r] = a[l];
                     b[--r] = b[l];
                  }
            }
            a[l] = pivot;
            b[l] = bpivot;
            begin[i+1] = l + 1;
            end[i+1] = end[i];
          } else {
            --i;
          }
          return;
   }
}

void quicksort_int( int a[], int rows) {

   int i, j, k, storedIndex, rtmp, l, r; //bpivot;
   int begin[1000], end[1000];
   float pivot, tmp;
  
   i = 0;
   begin[0] = 0;
   end[0] = rows;
   while (i >= 0) {
         l = begin[i];
         r = end[i]-1;
         if (l < r) {
            pivot = a[l];
      //      bpivot = b[l];
            if (i == 1000-1) return;
	    while (l < r) {
                  while (a[r] >= pivot && l < r) --r;
                  if (l < r) {
                     a[++l] = a[r];
    //                 b[++l] = b[r];
                  }
                  while (a[l] >= pivot && l < r) ++l;
                  if (l < r) {
                     a[--r] = a[l];
  //                   b[--r] = b[l];
                  }
            }
            a[l] = pivot;
//            b[l] = bpivot;
            begin[i+1] = l + 1;
            end[i+1] = end[i];
          } else {
            --i;
          }
          return;
   }
}
